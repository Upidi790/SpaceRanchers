import express from 'express';
import fetch from 'node-fetch';

// ---- Your DO agent info ----
const AGENT_ENDPOINT = 'https://txwsempt2gizrpziqyajxf7j.agents.do-ai.run';
const DO_KEY = '<XCW2TfpWW7htu5dhwNJLludkYsBMBhCc>';

const app = express();

// Robust CORS for file:// and all others
app.use((req, res, next) => {
  const origin = req.headers.origin || '*'; // will reflect null/localhost/etc.
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  // If you need cookies, also add: Access-Control-Allow-Credentials: true
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.use(express.json());

// Health page
app.get('/', (_req, res) => {
  res.type('text/plain').send('MilkyWayRanger proxy is running. POST /chat');
});

app.post('/chat', async (req, res) => {
  try {
    const { message } = req.body || {};
    if (!message) return res.status(400).json({ error: "Missing 'message'" });

    const r = await fetch(AGENT_ENDPOINT, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${DO_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ input: message }),
    });

    const data = await r.json().catch(() => ({}));
    if (!r.ok) return res.status(r.status).json(data);
    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err.message || err) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log(`✅ MilkyWayRanger proxy running on port ${PORT}`)
);
